package com.test.pages;

import org.testng.annotations.Test;

public class LoginPageObjectTest {
  @Test
  public void f() {
  }
}
