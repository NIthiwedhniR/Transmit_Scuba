ackage com.test.locators;

import org.testng.annotations.Test;

public class TestLocatorsCSSSelectorsTest {
  @Test
  public void f() {
  }
}
